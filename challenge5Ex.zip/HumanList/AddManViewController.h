//
//  AddManViewController.h
//  HumanList
//
//  Created by Peter Leonard on 5/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddManViewController : UIViewController
- (IBAction)handleInsert;
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *ageField;

@end

//
//  Man.h
//  HumanList
//
//  Created by Peter Leonard on 5/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Man : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * age;

-(NSComparisonResult)compareAge:(Man *)otherObject;

@end

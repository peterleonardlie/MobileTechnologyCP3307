//
//  AddManViewController.m
//  HumanList
//
//  Created by Peter Leonard on 5/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import "AddManViewController.h"
#import "AppDelegate.h"
#import "Man.h"

@interface AddManViewController (){
    
    AppDelegate* appDelegate;
}

@end

@implementation AddManViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    appDelegate = [UIApplication sharedApplication].delegate;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)handleInsert {
    
    NSString* name = _nameField.text;
    NSString* string = _ageField.text;
    
    NSNumber  *age = [NSNumber numberWithInteger: [string integerValue]];
    NSLog(@"%@",age);//NSString to NSNumber
    
    
    [_nameField resignFirstResponder];
    
    Man* man = [NSEntityDescription
                insertNewObjectForEntityForName:@"Man" inManagedObjectContext:appDelegate.managedObjectContext];
    
    man.name = name;
    man.age = age;
    
    [appDelegate saveContext];
    
}
@end

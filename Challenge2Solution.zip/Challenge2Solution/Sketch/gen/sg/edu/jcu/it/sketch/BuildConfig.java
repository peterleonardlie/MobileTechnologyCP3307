/** Automatically generated file. DO NOT MODIFY */
package sg.edu.jcu.it.sketch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package sg.edu.jcu.it.sketch;

public class Point {
	float x,y;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return x + ", " + y;
	}
}

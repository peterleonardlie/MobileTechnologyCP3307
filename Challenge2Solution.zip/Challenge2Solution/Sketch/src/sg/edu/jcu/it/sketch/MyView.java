package sg.edu.jcu.it.sketch;


import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

@SuppressLint("DefaultLocale") public class MyView extends View {
	
	private Paint paint;
	List<sg.edu.jcu.it.sketch.Point> points = new ArrayList<sg.edu.jcu.it.sketch.Point>();
	
	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		paint = new Paint();
		paint.setColor(Color.GRAY);
		
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		
		sg.edu.jcu.it.sketch.Point point = new sg.edu.jcu.it.sketch.Point();
        point.x = event.getX();
        point.y = event.getY();
        points.add(point);
    	String message = String.format("MyView X: %f; y: %f",point.x, point.y);
    	System.out.println(message);
    	
    	invalidate();
    	
    	return true;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		 for (sg.edu.jcu.it.sketch.Point point : points) {
	            canvas.drawCircle(point.x, point.y, 10, paint);
		 }
	}
}

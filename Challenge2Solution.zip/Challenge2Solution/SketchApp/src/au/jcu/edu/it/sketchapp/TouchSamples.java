package au.jcu.edu.it.sketchapp;

import java.util.Vector;

import android.graphics.Color;
import android.graphics.PointF;

public class TouchSamples {
	
	public interface TouchSamplesListener{
		void onSamplesChanged(TouchSamples samples);
	}
	private TouchSamplesListener listener;
	protected Vector<PointF> points;
	protected int size;
	protected int color;
	
	
	public TouchSamples(){
		points = new Vector<PointF>();
		size = 10;
		color = Color.RED;
	}
	
	public void setTouchSamplesListener(TouchSamplesListener touchSamplesListener){
		this.listener = touchSamplesListener;
	}
	
	public void clear(){
		points.clear();
	}

	public void add(PointF position) {
		points.add(position);
		notifyChanged();
		
	}
	
	public void notifyChanged(){
		if (listener == null) 
			return;
		
		listener.onSamplesChanged(this);
	}

	public void setSize(int size) {
		this.size = size;
		notifyChanged();
		
	}
	public void setColor(int color){
		this.color = color;
		notifyChanged();
	}

}

package au.jcu.edu.it.sketchapp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;
import au.jcu.edu.it.sketchapp.TouchSamples.TouchSamplesListener;

public class SettingsActivity extends Activity {
	
	private SketchApp app;
	private SketchView view;
	private SeekBar sizeSeekBar;
	private RadioGroup colorRadioGroup;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
		
		app = (SketchApp)getApplication();
		view = (SketchView)findViewById(R.id.sketchView1);
		view.setModel(app.touchSamplesModel);
		sizeSeekBar = (SeekBar)findViewById(R.id.seekBar1);
		colorRadioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
	}
	@Override
	protected void onStart() {
		
		super.onStart();
		
		//reset the UI
		sizeSeekBar.setProgress(app.touchSamplesModel.size - 1); //adjusted for progress
		colorRadioGroup.check(idFromColor(app.touchSamplesModel.color));
		
		view.invalidate();
		//wire up
		
		colorRadioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				int color = colorFromId(checkedId);
				app.touchSamplesModel.setColor(color);
				
			}
		});
		
		sizeSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				
				int size = progress + 1;
				app.touchSamplesModel.setSize(size);
				
				
			}
		});
		
		app.touchSamplesModel.setTouchSamplesListener(new TouchSamplesListener() {
			
			@Override
			public void onSamplesChanged(TouchSamples samples) {
				view.invalidate();
				
			}
		});
	}
	
	@Override
	public void onBackPressed() {
		Toast.makeText(this, "Press the Okay button", Toast.LENGTH_LONG).show();
	}
	
	public void okayPressed(View view){
		 finish();
	}
	
	private int idFromColor(int color){
		switch(color){
		case Color.RED:
			return R.id.radio0;
		case Color.GREEN:
			return R.id.radio1;
		case Color.BLUE:
			return R.id.radio2;
		}
		return -1;
	}
	
	private int colorFromId(int checkedId){
		switch(checkedId){
		case R.id.radio0:
			return Color.RED;
		case R.id.radio1:
			return Color.GREEN;
		case R.id.radio2:
			return Color.BLUE;
		}
		return Color.WHITE;
	}
	
}

package au.jcu.edu.it.sketchapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import au.jcu.edu.it.sketchapp.TouchSamples.TouchSamplesListener;


@SuppressLint("ClickableViewAccessibility") public class MainActivity extends Activity {
	
	private SketchApp app;
	private SketchView view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        app = (SketchApp) getApplication();
        view = (SketchView)findViewById(R.id.sketchView1);
        view.setModel(app.touchSamplesModel);
    }
    
    @SuppressLint("ClickableViewAccessibility") @Override
    protected void onStart() {	
    	super.onStart();
    	view.invalidate(); //force a redraw
    	//wire up
    	app.touchSamplesModel.setTouchSamplesListener(new TouchSamplesListener() {
			
			@Override
			public void onSamplesChanged(TouchSamples samples) {
				view.invalidate();
			}
		});
    	view.setOnTouchListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch(event.getAction()){
				case MotionEvent.ACTION_DOWN:
				case MotionEvent.ACTION_MOVE:
					
					PointF position = new PointF();
					position.x = event.getX();
					position.y = event.getY();
					app.touchSamplesModel.add(position);
					
					
					return true;
				}
				return false;
			}
		});
    }
     	
    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
    	switch (item.getItemId()){
    	case R.id.action_settings: 
    		Intent intent  = new Intent(this, SettingsActivity.class);
    		startActivity(intent);
    		return true;
    	}
    	return super.onMenuItemSelected(featureId, item);
    } 

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

package au.jcu.edu.it.sketchapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;

public class SketchView extends View {
	
	private TouchSamples TouchSamplesModel;
	private Paint paint;

	public SketchView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setBackgroundColor(Color.BLACK);
		paint = new Paint();
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if(TouchSamplesModel == null) return;
		
		for(PointF point : TouchSamplesModel.points){
			paint.setColor(TouchSamplesModel.color);
			float cx = point.x;
			float cy = point.y;
			float radius = TouchSamplesModel.size;
			canvas.drawCircle(cx, cy, radius, paint);
		}
	}

	public void setModel(TouchSamples model) {
		TouchSamplesModel = model;
		
	}
	
}


package au.jcu.edu.it.sketchapp;

import android.app.Application;

public class SketchApp extends Application {
	
	protected TouchSamples touchSamplesModel;
	
	@Override
	public void onCreate() {

		super.onCreate();
		
		touchSamplesModel = new TouchSamples();
		
	}
	
	@Override
	public void onLowMemory() {
		touchSamplesModel.clear();

		super.onLowMemory();
	}
	
	@Override
	public void onTerminate() {

		super.onTerminate();
	}
	

}

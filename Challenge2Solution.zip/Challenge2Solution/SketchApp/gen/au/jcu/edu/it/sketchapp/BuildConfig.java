/** Automatically generated file. DO NOT MODIFY */
package au.jcu.edu.it.sketchapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
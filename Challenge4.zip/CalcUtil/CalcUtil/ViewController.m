//
//  ViewController.m
//  CalcUtil
//
//  Created by Peter Leonard on 19/12/14.
//  Copyright (c) 2014 Peter Leonard. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (IBAction)onePressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)twoPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)threePressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)fourPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)fivePressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)sixPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)sevenPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)eightPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)ninePressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)zeroPressed:(id) sender {
    
    UIButton* button = sender;
    
    NSString* buttonText = button.titleLabel.text;
    
    int value = [buttonText intValue];
    
    sum = sum + value;
    
    lastDigit = value;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)clearPressed:(id)sender {
    
    ifReset = sum;
    
    sum = 0;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
}

- (IBAction)undoPressed:(id)sender {
    
    if (sum == 0){
        
        sum = ifReset;
        
        myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    }
    
    else {
    
    sum = sum - lastDigit;
    
    lastDigit = 0;
    
    myLabel.text = [NSString stringWithFormat: @"value: %d", sum];
    
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    sum = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

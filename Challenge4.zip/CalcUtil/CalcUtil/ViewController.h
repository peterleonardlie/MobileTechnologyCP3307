//
//  ViewController.h
//  CalcUtil
//
//  Created by Peter Leonard on 19/12/14.
//  Copyright (c) 2014 Peter Leonard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {

IBOutlet UILabel* myLabel;
    
    IBOutlet UITextField* myTextField;

int sum;
    
int lastDigit;
    
int ifReset;
    
}

@end


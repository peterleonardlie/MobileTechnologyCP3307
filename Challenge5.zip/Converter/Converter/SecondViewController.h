//
//  SecondViewController.h
//  Converter
//
//  Created by Peter Leonard on 4/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController {


IBOutlet UITextField* SGDTextField;

IBOutlet UITextField* USDTextField;
    
float count;
    
}

- (IBAction)returnKeyPressed:(id)sender;

@end


//
//  SecondViewController.m
//  Converter
//
//  Created by Peter Leonard on 4/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

-(IBAction)returnKeyPressed:(id)sender {
    
    [sender resignFirstResponder];
}

-(IBAction)SGDTextFieldPressed:(id)sender {
    
    NSString* input = SGDTextField.text;
    
    float value = [input floatValue];
    
    count = value * 0.751267;
    
    USDTextField.text = [ NSString stringWithFormat: @"%f", count];
    
}

-(IBAction)USDTextFieldPressed:(id)sender {
    
    NSString* input = USDTextField.text;
    
    float value = [input floatValue];
    
    count = value * 1.33109;
    
    SGDTextField.text = [ NSString stringWithFormat: @"%f", count];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

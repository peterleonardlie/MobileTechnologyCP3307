//
//  FirstViewController.h
//  Converter
//
//  Created by Peter Leonard on 4/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController {
    
    IBOutlet UITextField* myTextField;
    
    IBOutlet UILabel* myLabel;
    
}

-(IBAction)ConvertPressed:(id)sender;

-(IBAction)returnKeyPressed:(id)sender;


@end


//
//  AppDelegate.h
//  Converter
//
//  Created by Peter Leonard on 4/1/15.
//  Copyright (c) 2015 Peter Leonard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

